#include<iostream>
using namespace std;

int main()
{
     int A[5][5];
     int i,j;
     for(i=0;i<5;i++)
     {
         cout<<"Enter the elements of row "<<i+1<<endl;
         for(j=0;j<5;j++)
         {
             cin>>A[i][j];
         }
         cout<<endl;
     }
     int sum,index_r=-1,index_c=-1,largest;
     largest=-10000;
     for(i=0;i<5;i++)
     {
         sum=0;
         for(j=0;j<5;j++)
         {
             sum=sum+A[i][j];
         }
         if(largest<sum)
         {
             index_r=i;
             largest=sum;
         }

     }
     for(i=0;i<5;i++)
     {
         sum=0;
         for(j=0;j<5;j++)
         {
             sum=sum+A[j][i];
         }
         if(largest<sum)
         {
             index_c=i;
             index_r=-1;
             largest=sum;
         }

     }

     if(index_c==-1)
     {
         cout<<"\nLargest sum of elements is in the row "<<index_r+1;
     }
     else
     {
         cout<<"\n Largest sum of elements is in the column "<<index_c+1;
     }

     return 0;

}


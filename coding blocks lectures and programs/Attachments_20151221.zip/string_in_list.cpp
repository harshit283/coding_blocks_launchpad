#include<iostream>
using namespace std;

int length(char *str)
{
    int i=0;
    while(str[i]!='\0')
    {
        i++;
    }
    return i;
}


bool string_compare(char A[] , char B[])
{
    if((length(A))!=(length(B)))
    {
        return false;
    }
    int i;
    for(i=0;A[i]!='\0';i++)
    {
        if(A[i]!=B[i])
        {
            return false;
        }

    }
    return true;
}
bool check_if_in_the_list(char str[][100],int N, char S[] )
{
    int i,j;
    for(i=0;i<N;i++)
    {
        if(string_compare(str[i],S))
        {
            return true;
        }
    }
    return false;
}
int main()
{
    char str[100][100], S[100];
    cout<<"Enter the number of strings ";
    int N;
    cin>>N;
    int i,j;

    cin.getline(str[0],100);
    for(i=0;i<N;i++)
    {
        cout<<"Enter string "<<i+1<<endl;
        cin.getline(str[i],100);
    }
    cout<<"Enter the word "<<endl;
    cin.getline(S,100);
    if(check_if_in_the_list(str,N,S))
    {
        cout<<"\nYes the given string exists in the list";
    }
    else
    {
        cout<<"\nNo the given string does not exist in the list ";
    }

    return 0;
}

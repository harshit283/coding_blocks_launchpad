#include<iostream>
using namespace std;

int main()
{
     int A[5][4];
     int i,j;
     for(i=0;i<5;i++)
     {
         cout<<"Enter the elements of row "<<i+1<<endl;
         for(j=0;j<4;j++)
         {
             cin>>A[i][j];
         }
         cout<<endl;
     }
     cout<<"\n";
     for(i=0;i<4;i++)
     {
         for(j=0;j<5;j++)
         {
             if(i%2==1)
             {
                 cout<<A[4-j][i]<<" ";
             }
             else
             {
                 cout<<A[j][i]<<" ";
             }
         }
         cout<<"\n";
     }

     return 0;

}

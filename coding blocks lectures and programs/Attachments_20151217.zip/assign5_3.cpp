#include<iostream>
using namespace std;

void Pairs_summing_to_X(int A[], int N, int X)     //A is sorted
{
    int i=0, j=N-1, sum;

    while(i<j)
    {
        sum=A[i]+A[j];
        if(sum==X)
        {
             cout<<"\nPair found : "<<A[i]<<" at index "<<i<<" and "<<A[j]<<" at index "<<j;
             i++;
             j--;
        }
        else if(sum<X)
        {
            i++;
        }
        else
        {
            j--;
        }
    }
}

int main()
{
    int i,N, A[100];
    cout<<"Enter the size of the array ";
    cin>>N;
    cout<<"\nEnter the elements in the array(sorted) "<<endl;
    for(i=0;i<N;i++)
    {
        cin>>A[i];
    }
    int X;
    cout<<"\nEnter the value of Pair Sum to be found out ";
    cin>>X;
    Pairs_summing_to_X(A,N,X);
    return 0;
}


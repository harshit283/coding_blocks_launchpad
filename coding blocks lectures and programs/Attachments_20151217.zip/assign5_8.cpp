#include<iostream>
using namespace std;
int max_difference(int A[], int N)
{
    int i=0,j,k,pos;
    pos=-1;
    int difference=0;
    int s1,s2;

    while(i<N)
    {
        s1=0;s2=0;
        for(j=0;j<=i;j++)
        {
            s1=s1+A[j];
        }
        for(j=i+1;j<N;j++)
        {
            s2=s2+A[j];

        }
        if(difference<(s2-s1))
        {
            difference=s2-s1;
            pos=i;
        }
        i++;
    }

    return pos;

}

int main()
{
    int A[100], N, i;
    cout<<"Enter the size of the array ";
    cin>>N;
    cout<<"\nEnter the elements in the array "<<endl;

    for(i=0;i<N;i++)
    {
        cin>>A[i];
    }
    int j=max_difference(A,N);
    cout<<"\nThe required index is "<<j<<endl;
    cout<<"Array before the index ";
    for(i=0;i<=j;i++)
        cout<<A[i]<<" ";
    cout<<"\nArray after the index ";
    for(i=j+1;i<N;i++)
        cout<<A[i]<<" ";

    return 0;



}

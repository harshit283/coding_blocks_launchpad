#include<iostream>
using namespace std;

int bsearch(int A[], int N, int L)
{
    int Mid,pos=-1;
    int start=0, ed=N-1;
    while(start<=ed)
    {
        Mid=(start+ed)/2;
        if(A[Mid]==L)
        {
            pos=Mid;
            break;
        }
        else if(A[Mid]>L)
        {
            ed=Mid-1;
        }
        else
        {
            start=Mid+1;
        }
    }
    return pos;

}

int main()
{
    int A[100],N,L,i;
    cout<<"Enter the size of array ";
    cin>>N;
    cout<<"\nEnter the elements of the array( in sorted order ) "<<endl;
    for(i=0;i<N;i++)
    {
        cin>>A[i];
    }
    cout<<"\nEnter the element to be searched ";
    cin>>L;
    int k=bsearch(A,N,L);
    if(k==-1)
        cout<<"\nElement Not Found";
    else
        cout<<"\nElement Found at position "<<k+1;
    return 0;
}


#include<iostream>
using namespace std;

void Pairs_summing_to_X( int A[], int N, int X)
{
    int i,j;
    for(i=0;i<N-1;i++)
    {
        for(j=i+1;j<N;j++)
        {
            if(A[j]+A[i]==X)
                cout<<"\nPair found : "<<A[i]<<" at index "<<i<<" and "<<A[j]<<" at index "<<j;
        }
    }

}
int main()
{
    int A[100], N, X, i;
    cout<<"Enter the size of array ";
    cin>>N;
    cout<<"\nEnter the elements of the array "<<endl;
    for(i=0;i<N;i++)
    {
        cin>>A[i];
    }
    cout<<"\nEnter the Pair Sum ";
    cin>>X;
    Pairs_summing_to_X(A,N,X);
    return 0;



}


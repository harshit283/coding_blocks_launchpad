#include<iostream>
using namespace std;

int fibo(int N)
{
    int i=1,j=1,k=0;;

    while(k<N)
    {   k=i+j;
        if(k==N)
        {
            return 1;
        }
        else
        {
            i=j;
            j=k;

        }
    }
    return 0;

}

int main()
{
    int N;
    cout<<"Enter the number ";
    cin>>N;
    int i=fibo(N);
    if(i==1)
    {
        cout<<"\nYes The given number is a member of the Fibonacci series";

    }
    else
    {
        cout<<"\nNo  The given number is not the member of Fibonacci series";
    }
    return 0;
}




#include<iostream>
using namespace std;

void insertion_sort(int A[], int N)
{
    int i,j,temp;
    for(i=1;i<=N;i++)
    {
        j=i-1;
        temp=A[i];
        while((temp<A[j])&&(j>=0))
        {
            A[j+1]=A[j];
            j--;
        }
        A[j+1]=temp;
    }

}
int main()
{
    int A[100],N;
    cout<<"Enter the size of array ( <100) "<<endl;
    cin>>N;
    cout<<"\n";
    int i,j,k,temp;
    cout<<"Enter the array elements "<<endl;
    for(i=0;i<N;i++)
    {
        cin>>A[i];
    }
    insertion_sort(A,N);
     cout<<"\n";
    for(i=0;i<N;i++)
        cout<<A[i]<<" ";
    return 0;
}

#include<iostream>
using namespace std;

void remove_duplicates( int A[], int N)
{
    int i,j,k;
    i=0;
    while(i<N-1)
    {
        for(j=i+1;j<N;j++)
        {
            if(A[i]==A[j])
            {
                for(k=i;k<N;k++)
                {
                    A[k]=A[k+1];
                }
                N--;
                j--;
            }
        }
        i++;
    }
    cout<<"\nArray after  removing duplication ";
    for(i=0;i<N;i++)
    {
        cout<<A[i]<<" ";
    }
    return;
}

int main()
{
    int A[100], N, i;
    cout<<"Enter the size of the array ";
    cin>>N;
    cout<<"\nEnter the elements in the array "<<endl;

    for(i=0;i<N;i++)
    {
        cin>>A[i];
    }

    remove_duplicates(A, N);
    return 0;


}

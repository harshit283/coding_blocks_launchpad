#include<iostream>
using namespace std;

int main()
{
    int A[100][100],N;
    cout<<"Enter the size of the chess board ";
    cin>>N;
    cout<<"Enter the positions of queens. Input 1 at the position of the queen and 0 at \nother positions";
    cout<<"\nMake sure that you input only two '1s' in the chess board ";
    int i,j,k=0;
    int B[2][2];
    for(i=0;i<N;i++)
    {
        cout<<"\nEnter the positions in the row "<<i+1<<" of the chess board "<<endl;
        for(j=0;j<N;j++)
        {
            cin>>A[i][j];
            if(A[i][j]==1)
            {
                B[0][k]=i;
                B[1][k]=j;
                k++;
            }

        }
    }

    if((B[0][0]==B[0][1])||(B[1][0]==B[1][1])||((B[0][0]==B[1][0]&&B[0][1]==B[1][1]))||((B[0][0]-B[0][1])==(B[1][0]-B[1][1]))||((B[0][0]-B[0][1])==(B[1][1]-B[1][0])))
    {
        cout<<"\nUnsafe ";
    }
    else
        cout<<"\nSafe ";
    return 0;
}

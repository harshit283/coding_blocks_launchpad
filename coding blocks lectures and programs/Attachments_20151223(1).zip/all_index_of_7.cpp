#include<iostream>
using namespace std;
int i=0;

int index_seven(int A[], int B[],int start, int N)
{
    if(start==N)
        return i;
    if(A[start]==7)
        {
            B[i]=start;
            i++;

        }
    return index_seven(A,B,start+1,N);
}
int main()
{
    int A[100],N;
    int B[100];
    cout<<"Enter the size of the array ";
    cin>>N;
    cout<<"Enter the elements of the array "<<endl;
    int i;
    for(i=0;i<N;i++)
        cin>>A[i];
    cout<<"\nNumber of 7 in the array are "<<index_seven(A,B,0,N);
    cout<<" at positions ";
    int j=index_seven(A,B,0,N);
    for( i=0;i<j/2;i++)
        cout<<B[i]<<" ";
           return 0;
}


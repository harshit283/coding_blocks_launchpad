#include<iostream>
using namespace std;
int length(char *str)
{
    int i=0;
    while(str[i]!='\0')
    {
        i++;
    }
    return i;
}

int string_compare(char A[], char B[])
{
    int i,j,k=0;
    for(i=0;;i++)
    {
        if(A[i]<B[i])
        {
            break;
        }
        else if(A[i]>B[i])
        {
            k=1;
            break;
        }

    }
    return k;

}
void swap_string(char A[],char B[])
{
    char temp[100];
    int i;
    for(i=0;A[i]!='\0';i++)
    {
        temp[i]=A[i];

    }
    temp[i]='\0';
    for(i=0;B[i]!='\0';i++)
    {
        A[i]=B[i];
    }
    A[i]='\0';
    for(i=0;temp[i]!='\0';i++)
    {
        B[i]=temp[i];

    }
    B[i]='\0';

}

int main()
{
    char str[100][100];
    cout<<"Enter the number of strings ";
    int N;
    cin>>N;
    int i,j;
    cin.getline(str[0],100);
    for(i=0;i<N;i++)
    {
        cout<<"Enter string "<<i+1<<endl;
        cin.getline(str[i],100);
    }
    for(i=0;i<N-1;i++)
    {
        for(j=0;j<N-1-i;j++)
        {
            if(string_compare(str[j],str[j+1])==1)
            {
                swap_string(str[j],str[j+1]);
            }
        }

    }

    cout<<"\nStrings in lexicographical order "<<endl;
    for(i=0;i<N;i++)
    {
        cout<<str[i]<<endl;
    }
    return 0;

}


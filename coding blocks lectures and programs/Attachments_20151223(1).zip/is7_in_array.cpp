#include<iostream>
using namespace std;

bool is7_inaray(int A[],int N)
{
    if(N==0)
        return false;
    if(A[0]==7)
        return true;
    return is7_inaray(A+1,N-1);
}

int main()
{
    int A[100],N;
    cout<<"Enter the size of the array ";
    cin>>N;
    cout<<"Enter the elements of the array "<<endl;
    int i;
    for(i=0;i<N;i++)
        cin>>A[i];
    if(is7_inaray(A,N))
        cout<<"\nThe array contains 7 ";
    else
        cout<<"\nThe array does not contain 7 ";
    return 0;
}

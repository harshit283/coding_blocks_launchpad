#include<iostream>
using namespace std;
int length(char *str)
{
    int i=0;
    while(str[i]!='\0')
    {
        i++;
    }
    return i;
}

bool is_palindrome(char *A, int start, int end_index)
{
    if(start>end_index)
        return true;

    if(A[start]!=A[end_index])
    {
        return false;
    }

    return is_palindrome(A,start+1,end_index-1);


}
int main()
{
    char A[100];
    cout<<"Input the string "<<endl;
    cin.getline(A,100);
    if(is_palindrome(A,0,length(A)-1))
        cout<<"\nYes the given string is palindrome ";
    else
        cout<<"\nNo the given string is not palindrome";
    return 0;
}

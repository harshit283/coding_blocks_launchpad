#include<iostream>
using namespace std;

int index_seven(int A[], int N)
{
    if(N==0)
        return -1;
    if(A[N-1]==7)
        return N-1;
    return index_seven(A,N-1);
}
int main()
{
    int A[100],N;
    cout<<"Enter the size of the array ";
    cin>>N;
    cout<<"Enter the elements of the array "<<endl;
    int i;
    for(i=0;i<N;i++)
        cin>>A[i];
    cout<<"\nLast index of 7 is "<<index_seven(A,N);
           return 0;
}


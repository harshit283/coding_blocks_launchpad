#include<iostream>
using namespace std;

void reverse_array(int A[], int start,int end_array )
{
    if(start>end_array)
        return;
    int temp=A[start];
    A[start]=A[end_array];
    A[end_array]=temp;
    reverse_array(A,start+1,end_array-1);

}

int main()
{
    int A[100],N;
    cout<<"Enter the size of the array ";
    cin>>N;
    cout<<"Enter the elements of the array "<<endl;
    int i;
    for(i=0;i<N;i++)
        cin>>A[i];
    reverse_array(A,0,N-1);
    cout<<"\nNew Array "<<endl;
    for(i=0;i<N;i++)
        cout<<A[i]<<" ";
    return 0;
}

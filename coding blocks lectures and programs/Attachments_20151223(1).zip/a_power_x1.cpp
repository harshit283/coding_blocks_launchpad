#include<iostream>
using namespace std;

int a_power_x(int a, int x)
{
    if(x==1)
        return a;
    if(x%2==0)
        return a_power_x(a,x/2)*a_power_x(a,x/2);
    else
        return a_power_x(a,x/2)*a_power_x(a,x/2+1);


}

int main()
{
    int a,x;
    cout<<"Enter the value of base ";
    cin>>a;
    cout<<"Enter the value of power ";
    cin>>x;
    cout<<"Ans is "<<a_power_x(a,x);
    return 0;
}


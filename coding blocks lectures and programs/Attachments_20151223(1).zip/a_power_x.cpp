#include<iostream>
using namespace std;

int a_power_x(int a, int x)
{
    if(x==1)
        return a;
    return a*a_power_x(a,x-1);

}

int main()
{
    int a,x;
    cout<<"Enter the value of base ";
    cin>>a;
    cout<<"Enter the value of power ";
    cin>>x;
    cout<<"Ans is "<<a_power_x(a,x);
    return 0;
}

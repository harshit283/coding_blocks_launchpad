#include<iostream>
using namespace std;
void bubble_sort(int A[], int N)
{
    if(N==0)
        return;
    int i,temp;
    for(i=0;i<N-1;i++)
    {
        if(A[i]>A[i+1])
        {
            temp=A[i];
            A[i]=A[i+1];
            A[i+1]=temp;
        }
    }
    bubble_sort(A,N-1);
}

int main()
{
    int A[100],N;
    cout<<"Enter the size of the array ";
    cin>>N;
    cout<<"Enter the elements of the array "<<endl;
    int i;
    for(i=0;i<N;i++)
        cin>>A[i];
    bubble_sort(A,N);
    cout<<"\nNew Array "<<endl;
    for(i=0;i<N;i++)
        cout<<A[i]<<" ";
    return 0;
}


#include<iostream>
using namespace std;

int main()
{
    int A[100][100],N;
    cout<<"Enter the size of the chess board ";
    cin>>N;
    cout<<"Enter the positions of queens. Input 1 at the position of the queen and 0 at \nother positions";
    int i,j;
    for(i=0;i<N;i++)
    {
        cout<<"\nEnter the positions in the row "<<i+1<<" of the chess board "<<endl;
        for(j=0;j<N;j++)
        {
            cin>>A[i][j];
        }
    }
    int k,l,m;

    for(i=0;i<N;i++)
    {
        for(j=0;j<N;j++)
        {
            if(A[i][j]==1)
            {
              for(k=0;k<N;k++)
              {
                  if((k!=j)&&(A[i][k]==1))
                  {
                      cout<<"\nUnsafe ";
                      return 0;
                  }
              }
              for(k=0;k<N;k++)
              {
                  if((k!=i)&&(A[k][j]==1))
                  {
                      cout<<"\nUnsafe ";
                      return 0;
                  }
              }
              for(k=1;k<N;k++)
              {
                  if(k+i==N||k+j==N||i-k==0||j-k==0)
                  {
                      break;
                  }

                  if((A[k+i][k+j]==1)||(A[i-k][j-k]==1))
                  {
                      cout<<"\nUnsafe ";
                      return 0;
                  }
              }
              for(k=1;k<N;k++)
              {
                  if(k+i==N||k+j==N||i-k==0||j-k==0)
                  {
                      break;
                  }

                  if((A[k+i][j-k]==1)||(A[i-k][j+k]==1))
                  {
                      cout<<"\nUnsafe ";
                      return 0;
                  }
              }

            }
        }
    }

    cout<<"\nSafe";


}


#include<iostream>
using namespace std;

int index_seven(int A[], int start, int N)
{
    if(start==N)
        return -1;
    if(A[start]==7)
        return start;
    return index_seven(A,start+1,N);
}
int main()
{
    int A[100],N;
    cout<<"Enter the size of the array ";
    cin>>N;
    cout<<"Enter the elements of the array "<<endl;
    int i;
    for(i=0;i<N;i++)
        cin>>A[i];
    cout<<"\nFirst index of 7 is "<<index_seven(A,0,N);
           return 0;
}

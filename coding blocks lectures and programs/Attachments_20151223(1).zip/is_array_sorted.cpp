#include<iostream>
using namespace std;

bool if_sorted(int A[],int N)
{
    if(N==0)
        return true;
     if(A[0]>A[1])
        return false;
    return if_sorted(A+1,N-1);
}

int main()
{
    int A[100],N;
    cout<<"Enter the size of the array ";
    cin>>N;
    cout<<"Enter the elements of the array "<<endl;
    int i;
    for(i=0;i<N;i++)
        cin>>A[i];
    if(if_sorted(A,N))
        cout<<"\nThe array is sorted ";
    else
        cout<<"\nThe array is not sorted ";
    return 0;
}

#include<iostream>
using namespace std;

int length(char *str)
{
    int i=0;
    while(str[i]!='\0')
    {
        i++;
    }
    return i;
}


int main()
{
    int N;
    cout<<"Enter the number of strings ";
    cin>>N;

    int i,j,k,largest=0;;
    char str1[100],str2[100];
    cin.getline(str1,50);

    for(i=0;i<N;i++)
    {



        cout<<"\nInput the string "<<i+1<<endl;
        cin.getline(str1,100);
        j=length(str1);
        if(largest<j)
        {
            largest=j;
            for(k=0;str1[k]!='\0';k++)
            {
                str2[k]=str1[k];
            }
            str2[k]='\0';
        }

    }

    cout<<"Largest String is "<<endl;
    for(i=0;str2[i]!='\0';i++)
    {
        cout<<str2[i];
    }

    return 0;



}

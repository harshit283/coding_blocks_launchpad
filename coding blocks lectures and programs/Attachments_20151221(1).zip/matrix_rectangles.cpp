#include<iostream>
using namespace std;

int main()
{
    char ch[100][100];
    int N;
    cout<<"Enter the number of rows ";
    cin>>N;
    cout<<"\n";
    int i,j,k;
    for(i=0;i<N;i++)
    {
        for(j=0;j<N;j++)
        {
            ch[i][j]='X';
        }
    }
    for(i=0;i<N;i=i+2)
    {
        for(j=i;j<N-i;j++)
        {
            ch[i][j]='O';
        }
        for(j=i;j<N-i;j++)
        {
            ch[N-i-1][j]='O';
        }
        for(j=i;j<N-i;j++)
        {
            ch[j][i]='O';
        }
        for(j=i;j<N-i;j++)
        {
            ch[j][N-i-1]='O';
        }
    }

    cout<<"\n";
    for(i=0;i<N;i++)
    {
        for(j=0;j<N;j++)
        {
            cout<<ch[i][j]<<" ";
        }
        cout<<"\n";
    }
    return 0;




}

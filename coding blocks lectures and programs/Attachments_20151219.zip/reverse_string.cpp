#include<iostream>
using namespace std;

int length(char *str)
{
    int i=0;
    while(str[i]!='\0')
    {
        i++;
    }
    return i;
}

void reverse_string(char * A)
{
    int i=0,j=length(A)-1;
    char temp;

    while(i<=j)
    {
        temp=A[i];
        A[i]=A[j];
        A[j]=temp;
        i++;
        j--;
    }

    return;
}

int main()
{
    char ch[100];
    cout<<"Input the string "<<endl;
    cin.getline(ch,100);
    reverse_string(ch);
    cout<<"\nReversed String "<<endl;
    cout<<ch;
    return 0;

}

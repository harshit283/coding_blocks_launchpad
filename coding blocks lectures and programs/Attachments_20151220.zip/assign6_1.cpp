#include<iostream>
using namespace std;

int length(char *str)
{
    int i=0;
    while(str[i]!='\0')
    {
        i++;
    }
    return i;
}

void append( char * A, char * B)
{
    int i=length(B);
    int j=length(A);
    int k,l=0;
    for(k=j;k<i+j;k++)
    {
        A[k]=B[l];
        l++;
    }
    A[k]='\0';
    return;

}

int main()
{
    char A[100],B[40];

    cout<<"Enter the first string ";
    cin.getline(A,60);
    cout<<"\nEnter the second string ";
    cin.getline(B,40);
    append(A,B);
    cout<<"\nAppended String "<<endl;
    int i;
    for(i=0;A[i]!='\0';i++)
        cout<<A[i];

    return 0;

}


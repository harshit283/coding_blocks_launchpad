#include<iostream>
using namespace std;

void squeeze(char *str)
{
    int i,j,k;
    for(i=0;str[i]!='\0';i++)
    {
        if(str[i]==' ')
        {
            for(k=i;str[k]!='\0';k++)
            {
                str[k]=str[k+1];
            }
        }
    }
    cout<<"\n"<<str;
}

int main()

{
    int i,j,k;
    char ch[100];
    cout<<"Enter the string "<<endl;
    cin.getline(ch,100);
    squeeze(ch);
    return 0;


}

#include<iostream>
using namespace std;

int length(char *str)
{
    int i=0;
    while(str[i]!='\0')
    {
        i++;
    }
    return i;
}

int htoi(char *A)
{
    int i,j,k=0,l,m,n=0;
    for(i=(length(A)-1);i>=0;i--,n++)
    {
        if(A[i]=='A')
        {
            j=10;
        }
        else if(A[i]=='B')
        {
            j=11;
        }
        else if(A[i]=='C')
        {
            j=12;
        }
        else if(A[i]=='D')
        {
            j=13;
        }
        else if(A[i]=='E')
        {
            j=14;
        }
        else if(A[i]=='F')
        {
            j=15;
        }
        else if(A[i]=='1')
        {
            j=1;
        }
        else if(A[i]=='2')
        {
            j=2;
        }
        else if(A[i]=='3')
        {
            j=3;
        }
        else if(A[i]=='4')
        {
            j=4;
        }
        else if(A[i]=='5')
        {
            j=5;
        }
        else if(A[i]=='6')
        {
            j=6;
        }
        else if(A[i]=='7')
        {
            j=7;
        }
        else if(A[i]=='8')
        {
            j=8;
        }
        else if(A[i]=='9')
        {
            j=9;
        }
        l=1;
        for(m=0;m<n;m++)
            l=l*16;

        k=k+j*l;






    }
    return k;

}

int main()
{
    char ch[100];
    cout<<"Enter the string "<<endl;
    cin.getline(ch,100);
    cout<<"\nThe integer of equivalent of the number is "<<htoi(ch);
    return 0;
}

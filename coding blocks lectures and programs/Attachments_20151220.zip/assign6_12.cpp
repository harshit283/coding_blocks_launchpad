#include<iostream>
using namespace std;

void push_zeros(int A[], int N)
{
    int i,k,j;
    j=N;
    for(i=0;i<j;i++)
    {
        if(A[i]==0)
        {
            for(k=i;k<j-1;k++)
            {
                A[k]=A[k+1];
            }
            j--;
            i--;
        }
    }

    for(k=j;k<N;k++)
        A[k]=0;

    cout<<"\nNew Array "<<endl;
    for(i=0;i<N;i++)
    {
        cout<<A[i]<<" ";
    }
    return;
}


int main()
{
    int A[100],N;
    cout<<"Enter the size of the array ";
    cin>>N;
    cout<<"\nEnter the elements of the array "<<endl;
    int i;
    for(i=0;i<N;i++)
        cin>>A[i];

    push_zeros(A,N);
    return 0;
}

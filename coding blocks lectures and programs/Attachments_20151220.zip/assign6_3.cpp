#include<iostream>
using namespace std;


int main()
{
    char ch[100];
    cout<<"Input the string "<<endl;
    cin.getline(ch,100);
    int i,j,k;
    cout<<"\nThe substring are:- "<<endl;
    for(i=0;ch[i]!='\0';i++)
    {
        for(j=i;ch[j]!='\0';j++)
        {
            for(k=i;k<=j;k++)
            {
                cout<<ch[k];
            }
            cout<<"\n";

        }
    }
    return 0;

}





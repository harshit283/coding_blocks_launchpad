#include<iostream>
using namespace std;

int length(char *str)
{
    int i=0;
    while(str[i]!='\0')
    {
        i++;
    }
    return i;
}

int stringRseach(char *S, char *T)
{
    int i,j,k=0,l,m=0;
    j=length(T)-1;
    for(i=length(S)-1;i>=0;i--)
    {
        if(S[i]==T[j])
        {
           m++;
           j--;
           if(m==length(T))
           {
               m=m-length(T)+i;
               k=1;
               break;
           }
        }
        else
        {
            m=0;
        }

    }
    if(k==0)
    {
        return -1;
    }
    return m;

}

int main()
{
    cout<<"Enter the string "<<endl;
    char ch[100],str[100];
    cin.getline(ch,100);
    cout<<"\nEnter he substring "<<endl;
    cin.getline(str,100);

    int n=stringRseach(ch,str);
    if(n==-1)
        cout<<"\nNot Found ";
    else
        cout<<"\nFound at rightmost position of "<<n;
    return 0;
}

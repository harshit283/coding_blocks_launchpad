#include<iostream>
using namespace std;

int convert_char_to_int(char *str)
{
    int i,j,k=0;
    for(i=0;str[i]!='\0';i++)
    {
        if(str[i]=='1')
        {
            j=1;
        }
        else if(str[i]=='2')
        {
            j=2;
        }
        else if(str[i]=='3')
        {
            j=3;
        }
        else if(str[i]=='4')
        {
            j=4;
        }
        else if(str[i]=='5')
        {
            j=5;
        }
        else if(str[i]=='6')
        {
            j=6;
        }
        else if(str[i]=='7')
        {
            j=7;
        }
        else if(str[i]=='8')
        {
            j=8;
        }
        else if(str[i]=='9')
        {
            j=9;
        }
        else if(str[i]=='0')
        {
            j=0;
        }
        k=k*10+j;
    }
    return k;
}

void add_strings(char *s1, char *s2)
{
    int n=(convert_char_to_int(s1)+convert_char_to_int(s2));
    char ans[10];
    int i=0,j=n;
    while(j>0)
    {
        j=j/10;
        i++;

    }
    char ch;
    int k;
    for(j=i-1;j>=0;j--)
    {
        k=n%10;
        if(k==1)
        {
            ans[j]='1';
        }
        else if(k==2)
        {
            ans[j]='2';
        }
        else if(k==3)
        {
            ans[j]='3';
        }
        else if(k==4)
        {
            ans[j]='4';
        }
        else if(k==5)
        {
            ans[j]='5';
        }
        else if(k==6)
        {
            ans[j]='6';
        }
        else if(k==7)
        {
            ans[j]='7';
        }
        else if(k==8)
        {
            ans[j]='8';
        }
        else if(k==9)
        {
            ans[j]='9';
        }
        else if(k==0)
        {
            ans[j]='0';
        }

        n=n/10;
    }
    ans[i]='\0';
     cout<<"\nAnswer is "<<ans;
     return;
}

int main()
{
    char ch1[10],ch2[10];
    cout<<"Enter the first string ";
    cin.getline(ch1,10);
    cout<<"\nEnter the second string ";
    cin.getline(ch2,10);
    add_strings(ch1,ch2);
    return 0;

}






#include<iostream>
using namespace std;

int length(char *str)
{
    int i=0;
    while(str[i]!='\0')
    {
        i++;
    }
    return i;
}

int main()
{
    int N;
    char ch[100];

    cout<<"Input the string "<<endl;
    cin.getline(ch,100);
    cout<<"Enter the value by which the string is to be rotated ";
    cin>>N;
    int i=0,j=length(ch)-1;
    char temp;
    int k;
    while(i<N)
    {
        temp=ch[j];

            for(k=j;k>=0;k--)
            {
                ch[k]=ch[k-1];
            }
        ch[0]=temp;
        i++;

    }



    cout<<"\nFinal string "<<endl;
    cout<<ch;
    return 0;



}



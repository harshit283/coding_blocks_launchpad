#include<iostream>
using namespace std;

void compress(char *str)
{
    int i,j,k;
    for(i=0;str[i]!='\0';i++)
    {
        k=0;
        for(j=i;;j++)
        {
            if(str[i]==str[j])
            {
                k++;
            }
            else
            {
                break;
            }
        }
        cout<<str[i]<<k;
        i=j-1;

    }
    return;

}

int main()
{
    char ch[100];
    cout<<"Enter the string "<<endl;
    cin.getline(ch,100);
    cout<<"\nCompressed String "<<endl;
    compress(ch);
    return 0;

}



#include<iostream>
using namespace std;

int main()
{
    int A[100][100];
    int i,j,k;
    int N;
    cout<<"Enter the size of the matrix ";
    cin>>N;
    for(i=0;i<N;i++)
    {
        cout<<"Enter the elements of row (in sorted order) "<<i+1<<endl;
        for(j=0;j<N;j++)
        {
            cin>>A[i][j];
        }
    }
    int key;
    cout<<"\nEnter the element to be found out ";
    cin>>key;
    for(i=0;i<N;i++)
    {
        if(A[i][N-1]>=key)
        {
            break;
        }
    }

    for(j=0;i<N;j++)
    {
        if(A[i][N-j-1]==key)
        {
            cout<<"\nKey found at row index "<<i<<" and column index "<<j<<" : "<<A[i][N-j-1];
            break;
        }
    }

    if(j==N)
    {
        cout<<"\nKey not found ";
    }
    return 0;
}

#include<iostream>
using namespace std;

int main()
{
    int i,j,k;
    int A[100][100];
    int N,M;
    cout<<"Enter the number of rows in the matrix ";
    cin>>N;
    cout<<"Enter the number of columns in the matrix ";
    cin>>M;
    cout<<"Enter the array elements "<<endl;
    for(i=0;i<N;i++)
    {
        cout<<"Enter the elements of row "<<i+1<<endl;
        for(j=0;j<M;j++)
        {
            cin>>A[i][j];
        }
    }

    cout<<"\nSpiral Order "<<endl;
    for(i=0;i<N;i++)
    {
        for(j=i;j<N-i;j++)
        {
            cout<<A[i][j]<<" ";
        }
        for(j=i+1;j<N-i;j++)
        {
            cout<<A[j][N-i-1]<<" ";
        }
        for(j=N-i-2;j>=i;j--)
        {
            cout<<A[N-i-1][j]<<" ";
        }
        for(j=N-i-2;j>=i+1;j--)
        {
            cout<<A[j][i]<<" ";
        }


    }

    return 0;
}

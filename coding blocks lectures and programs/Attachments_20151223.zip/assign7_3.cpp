#include<iostream>
using namespace std;

int main()
{
    int i,j,k;
    int A[100][100];
    int N,M;
    cout<<"Enter the number of rows in the matrix ";
    cin>>N;
    cout<<"Enter the number of columns in the matrix ";
    cin>>M;
    cout<<"Enter the array elements "<<endl;
    for(i=0;i<N;i++)
    {
        cout<<"Enter the elements of row "<<i+1<<endl;
        for(j=0;j<M;j++)
        {
            cin>>A[i][j];
        }
    }

    int s,l=0;

    for(i=0;i<N;i++)
    {
        for(j=0;j<M;j++)
        {

            for(k=0;k<M;k++)
            {
                s=0;
                if((A[i][k])>(A[i][j]))
                {
                    s=1;
                    break;
                }
            }
            for(k=0;k<N;k++)
            {

                if(A[k][j]<A[i][j])
                {
                    s=1;
                    break;
                }
            }
            if(s==0)
            {
                l++;
                cout<<"\nSaddle point found at row index "<<i<<"and column index "<<j<<" : "<<A[i][j];
            }

        }
    }

    if(l==0)
    {
        cout<<"\nNo saddle point found ";
    }
    return 0;



}

#include<iostream>
using namespace std;

int length(char *str)
{
    int i=0;
    while(str[i]!='\0')
    {
        i++;
    }
    return i;
}

bool check_palindrome(char ch[])
{
    int i,j=length(ch)-1;
    for(i=0;i<j;i++,j--)
    {
        if(ch[i]!=ch[j])
        {
            return false;
        }

    }
    return true;
}

int main()
{
    char ch[100],B[100];
     cout<<"Input the string "<<endl;
    cin.getline(ch,100);
    int i,j,k,l,m=0;
    cout<<"\nThe substrings which are palindrome in the given string are "<<endl;
    for(i=0;ch[i]!='\0';i++)
    {
        for(j=i;ch[j]!='\0';j++)
        {
            for(k=i,l=0;k<=j;k++,l++)
            {
                B[l]=ch[k];
            }
            B[l]='\0';
            if(check_palindrome(B))
            {
                cout<<B<<endl;
                m++;
            }
        }
    }

    cout<<"\nNumber of substrings which are palindrome "<<m<<endl;
    return 0;

}

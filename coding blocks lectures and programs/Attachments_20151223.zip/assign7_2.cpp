#include<iostream>
using namespace std;

int main()
{
    int i,j,k;
    int A[100][100];
    int N;
    cout<<"Enter the size of the matrix ";
    cin>>N;
    cout<<"Enter the array elements "<<endl;
    for(i=0;i<N;i++)
    {
        cout<<"Enter the elements of row "<<i+1<<endl;
        for(j=0;j<N;j++)
        {
            cin>>A[i][j];
        }
    }

    for(i=0;i<N;i++)
    {
        for(j=0;j<N;j++)
        {
            if(A[i][j]==0)
            {
                for(k=0;k<N;k++)
                {
                    if(A[i][k]!=0)
                    {
                        A[i][k]=2;
                    }
                }
                for(k=0;k<N;k++)
                {
                    if(A[k][j]!=0)
                    {
                        A[k][j]=2;
                    }
                }
            }
        }
    }
    for(i=0;i<N;i++)
    {
        for(j=0;j<N;j++)
        {
            if(A[i][j]==2)
            {
                A[i][j]=0;
            }
        }
    }

    cout<<"\nNew matrix is "<<endl;
    for(i=0;i<N;i++)
    {
        for(j=0;j<N;j++)
        {
            cout<<A[i][j]<<" ";
        }
        cout<<endl;
    }

    return 0;
}
